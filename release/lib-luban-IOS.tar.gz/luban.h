#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

char *keygen(const char *addr, const char *params, const char *code);

char *sign(const char *addr,
           const char *keyshare,
           const char *params,
           const char *message,
           const char *code,
           const char *path);
