#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

char *keygen(const char *addr, const char *params, const char *code);

char *sign(const char *addr,
           const char *keyshare,
           const char *params,
           const char *message,
           const char *code,
           const char *path);

char *mkeygen(const char *addr,
              const char *params,
              const char *code,
              const char *phrase,
              const char *passwd);

char *newmkeygen(const char *addr,
                 const char *params,
                 const char *code,
                 const char *phrase_length,
                 const char *passwd);

char *pubkey(const char *keyshare, const char *path);
